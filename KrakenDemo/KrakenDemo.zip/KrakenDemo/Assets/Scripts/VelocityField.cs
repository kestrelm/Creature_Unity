﻿using UnityEngine;
using System.Collections;

public class VelocityField : MonoBehaviour {
	public float visc = 0.05f;
	public int iterations = 20;
	public float particleSpeed = 100;
	public float particleFadeAlphaFactor = 5.0f;
	public float particle_size = 0.01f;
	public float particle_base_alpha = 1.0f;
	public float particle_max_size = 0.01f;
	public float wall_vel = 0.01f;
	public ParticleSystem particle_system;
	ParticleSystem.Particle[] fluid_particles;
	/*public Texture2D border;
	public Texture2D flow;*/
	
	Texture2D tex;
	int width, height;
	float[,] u, v, u_prev, v_prev;
	int numParticles = 10000;
	Particle[] particles;
	/*float[,] bndX, bndY;
	float[,] velX, velY;*/

	void Start() {
		// duplicate the original texture and assign to the material
		tex = Instantiate(GetComponent<Renderer>().material.mainTexture) as Texture2D;
		GetComponent<Renderer>().material.mainTexture = tex;
		// get grid dimensions from texture
		width = tex.width;
		height = tex.height;
		// initialize velocity arrays
		u = new float[width, height];
		v = new float[width, height];
		u_prev = new float[width, height];
		v_prev = new float[width, height];
		// random position for particles
		particles = new Particle[numParticles];
		for (int i = 0; i < numParticles; i++) {
			particles[i].x = Random.Range(1, width-2);
			particles[i].y = Random.Range(1, height-2);
		}

		fluid_particles = new ParticleSystem.Particle[numParticles];

		/*// read border and velocity data from textures
		bndX = new float[width, height];
		bndY = new float[width, height];
		velX = new float[width, height];
		velY = new float[width, height];
		for (int j = 0; j < height-1; j++) {
			for (int i = 0; i < width-1; i++) {
				bndX[i, j] = border.GetPixel(i, j).grayscale - border.GetPixel(i+1, j).grayscale;
				bndY[i, j] = border.GetPixel(i, j).grayscale - border.GetPixel(i, j+1).grayscale;
				velX[i, j] = (flow.GetPixel(i, j).grayscale - flow.GetPixel(i+1, j).grayscale);
				velY[i, j] = (flow.GetPixel(i, j).grayscale - flow.GetPixel(i, j+1).grayscale);
			}
		}*/
	}

	void Update() {
		/*for (int j = 1; j < height-1; j++) {
			for (int i = 1; i < width-1; i++) {
				u[i, j] = velX[i, j];
				v[i, j] = velY[i, j];
			}
		}*/
		UserInput();
		VelStep();
		ApplyWallVel ();
		MoveParticles();
		Draw();
	}

	void SetBounds(int b, float[,] x) {
		/*// b/w texture as obstacles
		for (int j = 1; j < height; j++) {
			for (int i = 1; i < width; i++) {
				if (bndX[i, j] < 0) {
					x[i, j] = (b == 1) ? -x[i+1, j] : x[i+1, j];
				}
				if (bndX[i, j] > 0) {
					x[i, j] = (b == 1) ? -x[i-1, j] : x[i-1, j];
				}
				if (bndY[i, j] < 0) {
					x[i, j] = (b == 2) ? -x[i, j+1] : x[i, j+1];
				}
				if (bndY[i, j] > 0) {
					x[i, j] = (b == 2) ? -x[i, j-1] : x[i, j-1];
				}
			}
		}*/
		// rect borders
		float sign;
		// left/right: reflect if b is 1, else keep value before edge
		sign = (b == 1) ? -1 : 1;
		for (int i = 1; i < height-1; i++) {
			x[0, i] = sign * x[1, i];
			x[width-1, i] = sign * x[width-2, i];
		}
		// bottom/top: reflect if b is 2, else keep value before edge
		sign = (b == 2) ? -1 : 1;
		for (int i = 1; i < width-1; i++) {
			x[i, 0] = sign * x[i, 1];
			x[i, height-1] = sign * x[i, height-2];
		}
		// vertices
		x[0, 0]				 = 0.5f * (x[1, 0] + x[0, 1]);
		x[width-1, 0]		 = 0.5f * (x[width-2, 0] + x[width-1, 1]);
		x[0, height-1]		 = 0.5f * (x[1, height-1] + x[0, height-2]);
		x[width-1, height-1] = 0.5f * (x[width-2, height-1] + x[width-1, height-2]);
	}

	void Diffuse(int b, float[,] x, float[,] x0, float a, float c) {
		for (int k = 0; k < iterations; k++) {
			for (int j = 1; j < height-1; j++) {
				for (int i = 1; i < width-1; i++) {
					x[i, j] = (x0[i, j] + a * (x[i-1, j] + x[i+1, j] + x[i, j-1] + x[i, j+1])) / c;
				}
			}
			SetBounds(b, x);
		}
	}
	
	void Project(float[,] u, float[,] v, float[,] p, float[,] div) {
		float h = 1 / Mathf.Sqrt(width * height);
		for (int j = 1; j < height-1; j++ ) {
			for (int i = 1; i < width-1; i++) {
				div[i, j] = -0.5f * h * (u[i+1, j] - u[i-1, j] + v[i, j+1] - v[i, j-1]);
				p[i, j] = 0;
			}
		}
		SetBounds(0, div);
		SetBounds(0, p);
		
		Diffuse(0, p, div, 1, 4);

		for (int j = 1; j < height-1; j++) {
			for (int i = 1; i < width-1; i++) {
				u[i, j] -= 0.5f * (p[i+1, j] - p[i-1, j]) / h;
				v[i, j] -= 0.5f * (p[i, j+1] - p[i, j-1]) / h;
			}
		}
		SetBounds(1, u);
		SetBounds(2, v);
	}

	void VelStep() {
		float a = Time.deltaTime * visc * width * height;
		Diffuse(1, u, u, a, 1 + 4 * a);
		Diffuse(2, v, v, a, 1 + 4 * a);
		Project(u, v, u_prev, v_prev);
	}
	
	void UserInput() {
		if (Input.GetMouseButton(0)) {
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit hit;
			if (Physics.Raycast(ray, out hit, 100)) {
				// determine indices where the user clicked
				int x = (int)(hit.point.x * width);
				int y = (int)(hit.point.z * width);
				if (x < 1 || x >= width || y < 1 || y >= height) return;
				// add velocity
				u[x, y] += Input.GetAxis("Mouse X");
				v[x, y] += Input.GetAxis("Mouse Y");
			}
		}
	}

	public void InputVelocity(Vector2 position, Vector2 add_vel)
	{
		// transform into local space
		Vector2 originPos = new Vector2 (-transform.localScale.x * 0.25f, -transform.localScale.y * 0.5f);
		Vector2 relPos = position - originPos;
		Vector2 gridPos = new Vector2 (relPos.x / transform.localScale.x * (float)width,
		                               relPos.y / transform.localScale.y * (float)height);

		int x = (int)gridPos.x;
		int y = (int)gridPos.y;

		if (x < 0 || x > width - 1 || 
		    y < 0 || y > height - 1) 
		{
			// out of bounds
			return;
		}

		u[x, y] += add_vel.x;
		v[x, y] -= add_vel.y;

		/*
		int emit_num = 0;
		int i = 0;
		foreach (ParticleSystem.Particle curParticle in fluid_particles) {
			if(curParticle.velocity.magnitude < 10.0f)
			{
				particles[i].x = gridPos.x;
				particles[i].y = gridPos.y;
				emit_num++;
				if(emit_num > 100)
				{
					break;
				}
			}

			i++;
		}
		*/
	}

	public void ApplyWallVel()
	{
		/*
		for(int i = 0; i < width; i++)
		{
			v[i, 0] += wall_vel;
			v[i, height - 2] += -wall_vel;
		}

		for (int i = 0; i < height; i++) {
			u[0, i] += wall_vel;
			u[width - 2, i] += -wall_vel;
		}
		*/
	}
	
	void Draw() {
		// visualize water
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				float mag = v[x, y] * v[x, y] + u[x, y] * u[x, y] * 10;
				float final_mag = Mathf.Min(0.15f, mag);

				tex.SetPixel(x, y, new Color(final_mag + 0.05f, final_mag + 0.05f, final_mag + 0.1f, 0.7f));
			}
		}

		tex.Apply(false);
	}

	void MoveParticles() {
		for (int i = 0; i < numParticles; i++) {
			float pX = particles[i].x;
			float pY = particles[i].y;

			float pxVel = Bilin(u, pX, pY) * Random.Range (0.5f, 1.0f) * particleSpeed;
			float pyVel = Bilin(v, pX, pY) * Random.Range (0.5f, 1.0f) * particleSpeed;
			particles[i].x = pX += pxVel;
			particles[i].y = pY += pyVel;
			if (pX < 1 || pX > width-2 || pY < 1 || pY > height-2) {
				if(pX <1) {
					pX = Random.Range (1, width - 2);
				}
				else if(pX > width - 2)
				{
					pX = Random.Range (1, width - 2);
				}

				if(pY <1) {
					pY = Random.Range (1, height - 2);
				}
				else if(pY > height - 2)
				{
					pY = Random.Range (1, height - 2);
				}

				particles[i].x = pX;
				particles[i].y = pY;
			}

			// Update actual fluid particles
			Vector3 new_pos = new Vector3(particles[i].x / (float)(width + 1), 
			                              particles[i].y / (float)(height + 1), 0.0f);
			new_pos.x *= transform.localScale.x;
			new_pos.y *= transform.localScale.y;

			new_pos.x -= transform.localScale.x * 0.5f;
			new_pos.y -= transform.localScale.y * 0.5f;

			float particle_real_speed = Mathf.Sqrt(pxVel * pxVel + pyVel * pyVel);
			if(particle_real_speed < 0.1f)
			{
				pX = Random.Range (1, width - 2);
				pY = Random.Range (1, height - 2);
				particles[i].x = pX;
				particles[i].y = pY;
			}

			float particle_alpha = particle_real_speed / particleFadeAlphaFactor;

			fluid_particles[i].position = new_pos;
			fluid_particles[i].size = Mathf.Min(particle_max_size, particle_size * particle_alpha * particle_base_alpha);
			fluid_particles[i].lifetime = 100000.0f;
			fluid_particles[i].color = new Color(1, 1, 1, particle_alpha * particle_base_alpha);
		}

		particle_system.SetParticles (fluid_particles, numParticles);
	}

	float Bilin(float[,] field, float xPos, float yPos) {
		xPos -= 0.5f;
		yPos -= 0.5f;
		// casting to int is like floor
		int xInt = Mathf.Clamp((int)xPos, 1, width-2);
		int yInt = Mathf.Clamp((int)yPos, 1, height-2);
		// so diff is always positive
		float xDiff = xPos - xInt;
		float yDiff = yPos - yInt;
		// bilinear interpolation
		float cRow = (1 - xDiff) * field[xInt, yInt] + xDiff * field[xInt+1, yInt];
		float nRow = (1 - xDiff) * field[xInt, yInt+1] + xDiff * field[xInt+1, yInt+1];
		return (1 - yDiff) * cRow + yDiff * nRow;
	}

	struct Particle {
		public float x;
		public float y;
	}
}
